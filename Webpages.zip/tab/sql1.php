<?php
$db = new PDO("mysql:host=localhost;dbname=demo","root","");
foreach($db->query('SELECT * FROM status') as $row) 
echo $row['AC1'];
?>
