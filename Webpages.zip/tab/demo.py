from websocket import create_connection
import sys
import ssl
import MySQLdb
i1=0
i2=0
i3=0
i4=0
def map1(x, in_min, in_max, out_min, out_max):
	return int((x-in_min) * (out_max-out_min) / (in_max-in_min) + out_min)
while 1:
	str=""
	db=MySQLdb.connect(user="root",passwd="123456",db="demo")
	
	cursor = db.cursor()
	ws = create_connection("ws://192.168.16.76")
	print ("Processing...")
	str=sys.argv[1]
	ws.send(str)
	if str=="DATA":
		print ("Receiving...")
		result=ws.recv()
		print(result)
		print(len(result))
		if len(result)<5:
			ws.close()
			continue
		l=list(result)
		i1=ord(l[0])
		i2=ord(l[1])
		i3=ord(l[2])
		i4=ord(l[3])
		v=ord(l[4])
		if(i1>2):
			cursor.execute("UPDATE statusled SET AC1 = 'ON' LIMIT 1");
			db.commit()
		else:
			cursor.execute("UPDATE statusled SET AC1 = 'OFF' LIMIT 1");
			db.commit()
		if(i2>2):
			cursor.execute("UPDATE statusled SET AC2 = 'ON' LIMIT 1");
			db.commit()
		else:
			cursor.execute("UPDATE statusled SET AC2 = 'OFF' LIMIT 1");
			db.commit()
		if(i3>2):
			cursor.execute("UPDATE statusled SET AC3 = 'ON' LIMIT 1");
			db.commit()
		else:
			cursor.execute("UPDATE statusled SET AC3 = 'OFF' LIMIT 1");
			db.commit()
		if(i4>2):
			cursor.execute("UPDATE statusled SET AC4 = 'ON' LIMIT 1");
			db.commit()
		else:
			cursor.execute("UPDATE statusled SET AC4 = 'OFF' LIMIT 1");
			db.commit()
		
		if(i1==1):
			i1=0;
		if(i2==1):
			i2=0;
		if(i3==1):
			i3=0;
		if(i4==1):
			i4=0;
		if(v==1):
			v=0;

		i1=map1(i1,0,60,0,15);
		i2=map1(i2,0,30,0,15);
		i3=map1(i3,0,60,0,15);
		i4=map1(i4,0,60,0,15);
		v=map1(v,50,90,210,240);
		
		fo = open("foo.txt", "w")
		fo.write("Current1:%s" % i1)
		fo.write("\nCurrent2:%s" % i2)
		fo.write("\nCurrent3:%s" % i3)
		fo.write("\nCurrent4:%s" % i4)
		fo.write("\nCurrent5:%s" % v)
		str=""

		fo.close()	
	ws.close()
