<?php
//refresh page
$url=$_SERVER['REQUEST_URI'];
header("Refresh: 60; URL=$url");
// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demo";
echo '<link rel="stylesheet" type="text/css" href="style.css"></head>';
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "<div class='topnav'><a class='active' href='welcome1.php'>Home</a><a href='morris_ex1.php'>Graph</a></div>";
//$sql = "SELECT status, date_time FROM LED_STATUS WHERE date_time=MAX(date_time)";
//$sql = "SELECT * FROM temp1";
//$result = $conn->query($sql);

/*if ($result->num_rows > 0) {
    // output data of each row
  while($row = $result->fetch_assoc() ){
	echo "<table table-layout:fixed border-collapse:collapse width:35%><tr>";
        echo "<td>" . $row["tmp"]. "</td>" ;
        echo "<td>" . $row["cond"]. "</td>" ;
	echo "<td>" . $row["date_time"]. "</td>";
	echo "</tr></table>";
  }

} else {
    echo "0 results";
}*/
$conn->close();
?>
