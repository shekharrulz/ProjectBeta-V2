
<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8" />
<iframe id=myIframe style="border:none;float:right" height="500" width="300"></iframe>
	<title>LAB 1</title>
	<link rel="stylesheet" href="style3.css">
	<style>
	.enjoy-css {
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box;
  margin: -33px;
  padding: 28px;
  border: 2px solid;
  font: normal normal bold 36px/1 "Lucida Console", Monaco, monospace;
  color: white;
  text-align: center;
  text-indent: 190px;
  -o-text-overflow: ellipsis;
  text-overflow: ellipsis;
  letter-spacing: 6px;
  word-spacing: -3px;
  background: url("http://enjoycss.com/bg-img/custom/4400-1u5fn64.jpg");
  background-position: 42% -22%;
  -webkit-background-origin: padding-box;
  background-origin: padding-box;
  -webkit-background-clip: border-box;
  background-clip: border-box;
  -webkit-background-size: auto auto;
  background-size: auto auto;
  -webkit-box-shadow: 4px 4px 6px 1px rgba(0,0,0,0.4) ;
  box-shadow: 4px 4px 6px 1px rgba(0,0,0,0.4) ;
  text-shadow: 4px 4px 6px rgba(0,0,0,0.5) ;
  -webkit-transition: all 200ms cubic-bezier(0.42, 0, 0.58, 1) 10ms;
  -moz-transition: all 200ms cubic-bezier(0.42, 0, 0.58, 1) 10ms;
  -o-transition: all 200ms cubic-bezier(0.42, 0, 0.58, 1) 10ms;
  transition: all 200ms cubic-bezier(0.42, 0, 0.58, 1) 10ms;
  -webkit-transform: rotateX(-9.740282517223996deg) rotateY(0.5729577951308232deg)   ;
  transform: rotateX(-9.740282517223996deg) rotateY(0.5729577951308232deg)   ;
}

</style>
	<?php
	$db = new PDO("mysql:host=localhost;dbname=demo","root","");
	foreach($db->query('SELECT * FROM status') as $row)
	?>	
	<script type="text/javascript" src="jquery-1.7.2.min.js"></script>
	<script type="text/javascript">
		
	window.setInterval("reloadIFrame();", 1000);
	function reloadIFrame() {
 	document.getElementById("myIframe").src="piboy.php";
	}

	
		var x=0;
		var y=0;
		var z=0,a=0;
		var h=0,m=0,s=0;
		var today = new Date();
				h=today.getHours();
				m=today.getMinutes();
				s=today.getSeconds();
		var string,string1,string2,string3;
function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('txt').innerHTML =
    h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
		$(document).ready(function(){
				
				string = "<?php echo $row['AC1']; ?>";
				
				if(string == "ON")
				{x=1;
				$('#button').toggleClass('on');
				}				
				else
				x=0;
				string1 = "<?php echo $row['AC2']; ?>";
				
				if(string1 == "ON")
				{y=1;
				$('#button1').toggleClass('on');
				}				
				else
				y=0;
				string2 = "<?php echo $row['AC3']; ?>";
				
				if(string2 == "ON")
				{z=1;
				$('#button2').toggleClass('on');
				}				
				else
				z=0;
				string3 = "<?php echo $row['AC4']; ?>";
				
				if(string3 == "ON")
				{a=1;
				$('#button3').toggleClass('on');
				}				
				else
				a=0;
			$('#button').on('click', function(){
				
				if(x%2==0)
				{
				
				 $(this).toggleClass('on');
				 $.post("demo.php",{
				 status:"on"});
			        $.post("demo2.php",{
				status:"ON"},function(data) {
                     $('#stage').html(data);
                  });
				
				}
				
				else
				{
				$(this).toggleClass('on');
				$.post("demo.php",{
				status:"off"});
				$.post("demo2.php",{
				status:"OFF"},function(data) {
                     $('#stage').html(data);
                  });
				
				}
				x++;
			});
			$('#button1').on('click', function(){
				$(this).toggleClass('on');
				if(y%2==0)
				{
								
				$.post("demo.php",{
				status:"ona"});
				$.post("demo3.php",{
				status:"ONA"},function(data) {
                     $('#stage').html(data);
                  });			
				
				}
				else
				{
				$.post("demo.php",{
				status:"offa"});
				$.post("demo3.php",{
				status:"OFFA"},function(data) {
                     $('#stage').html(data);
                  });
				
				}
				y++;
			});
			$('#button2').on('click', function(){
				$(this).toggleClass('on');
				if(z%2==0)
				{
				
				$.post("demo.php",{
				status:"onb"},function(data) {
                     	$('#stage').html(data)});
				$.post("demo4.php",{
				status:"ONB"},function(data) {
                     $('#stage').html(data);
                  });		
				}
			
			
				
				else
				{
				$.post("demo.php",{
				status:"offb"});
				$.post("demo4.php",{
				status:"OFFB"},function(data) {
                     $('#stage').html(data);
                  });
				
				}
				z++;
			});
			$('#button3').on('click', function(){
				$(this).toggleClass('on');
				if(a%2==0)
				{
				
				$.post("demo.php",{
				status:"onc"});		
				$.post("demo5.php",{
				status:"ONC"},function(data) {
                     $('#stage').html(data);
                  });		
				
				
				}
				else
				{
				$.post("demo.php",{
				status:"offc"});
				$.post("demo5.php",{
				status:"OFFC"},function(data) {
                     $('#stage').html(data);
                  });
			
				}
				a++;
			});
		});
	</script>
</head>


	<section>
		<a href="#" id="button" >AC 1</a>
		<a1 href="#" id="button1" >AC 2</a1>
		<a2 href="#" id="button2" >AC 3</a2>
		<a3 href="#" id="button3" >AC 4</a3>
		<span></span>
	</section>

</body>

 
</html>
  
