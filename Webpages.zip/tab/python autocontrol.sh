#!/bin/sh

while true; do
  nohup python3 demo.py "DATA" >> demo.out
  nohup python3 on.py "DATA" >> on.out
done &


