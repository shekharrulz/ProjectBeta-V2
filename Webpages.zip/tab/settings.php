<?php
// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}
$displayname=$_SESSION['username'];
date_default_timezone_set("Asia/Kolkata");
$date = date('d/m/Y h:i a', time());
echo "<div class='topnav'><a href='#'>Embedded Power Supervisor - Settings</a>";
echo "<a class='active'href='button.php'>Home</a>";
echo "<a href='#'>";
echo "<div class='dropdown '>";
echo $displayname;
echo "<div class='dropdown-content'>";
echo "<a href='logout.php'>Logout</a></div>";
echo "</a></div>";
echo "<a class='right'>";
echo $date;
echo "</a></div>";

if($_SERVER["REQUEST_METHOD"] == "POST"){
$starttime = $_POST["usr_time1"];
$endtime=$_POST["usr_time2"];

$my_file = 'timer.txt';
$handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);

fwrite($handle, $starttime);
fclose($handle);
$my_file = 'timer1.txt';
$handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);

fwrite($handle, $endtime);
fclose($handle);
}

if($_SERVER["REQUEST_METHOD"] == "GET"){

$text = $_GET["textboy"];
$my_file = 'textboy.txt';
$handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);

fwrite($handle, $text);
fclose($handle);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Settings</title>
    <link rel="stylesheet" href="bootstrap.css">
   
    <style type="text/css">
        body{ font: 25px sans-serif; }
       .text-bot {
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box;
  position: relative;
  top: 700px;
  bottom: -34px;
  left: 0;
  padding: 10px;
  border: none;
  -webkit-border-radius: 29px / 3px;
  border-radius: 29px / 3px;
  font: normal 16px/1 "Comic Sans MS", cursive, sans-serif;
  color: rgba(165,9,9,1);
  text-indent: 400px;
  -o-text-overflow: ellipsis;
  text-overflow: ellipsis;
  background: rgba(183,133,45,1);
  -webkit-box-shadow: 3px 3px 6px 1px rgba(0,0,0,1) ;
  box-shadow: 3px 3px 6px 1px rgba(0,0,0,1) ;
}
.right {
    position: absolute;
    right: 0px;
    width: 300px;
    padding: 10px;
}

.topnav {
  position: relative;
  top: 0;
  width: 100%;
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 16px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
}

.navbar a:hover, .dropdown:hover .dropbtn {
    background-color: red;
}

.dropdown-content {
    display: none;
    position: fixed;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    position: fixed;
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #ddd;
}

.dropdown:hover .dropdown-content {
    display: block;}
table {
    table-layout: fixed;
    border-collapse: collapse;
    width: 100%;
        font-weight: 900;

}

th, td {
    padding: 8px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

tr:hover {background-color:#4CAF50;}

:active, :focus {
	outline: 0;
}
    </style>
</head>
<body>

        <h2>&nbsp&nbspSettings</h2>
        <br>
	
            <p>&nbsp&nbsp > Want to Add a department user? <a href="register.php">Click here</a>.</p>
	    <br>
	    <p>&nbsp&nbsp > Change time alloted?</p>
	     <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
	    &nbsp&nbsp&nbspSelect starting time:
	    <input type="time" name="usr_time1">
            <br>
	    <br>
	    &nbsp&nbsp&nbspSelect Ending time:
	    <input type="time" name="usr_time2">
             <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
            </div>
        </form>
	<p>&nbsp&nbsp > Custom message:</p>
       <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="get">
	<input type="textarea" name="textboy">
       <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
            </div>
       </form>
</body>
</html>
