<?php

if($_REQUEST["status"])
{
$data = $_REQUEST["status"];
$my_file = 'on_off.txt';
$handle = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);

fwrite($handle, $data);
fclose($handle);
}
?>
