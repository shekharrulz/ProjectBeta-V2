#!/bin/sh

while true; do
  nohup python demo.py "DATA" >> test.out
done &
