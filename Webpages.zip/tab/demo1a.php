<?php
// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}
$displayname=$_SESSION['username'];
date_default_timezone_set("Asia/Kolkata");
$date = date('d/m/Y h:i a', time());
echo "<div class='topnav'><a href='#'>Embedded Power Supervisor</a>";

echo "<a href='#'>";
echo "<div class='dropdown '>";
echo $displayname;
echo "<div class='dropdown-content'>";
echo "<a href='logout.php'>Logout</a></div>";
echo "</a></div>";
echo "<a class='right'>";
echo $date;
echo "</a></div>";

$my_file = 'timer.txt';
$handle = fopen($my_file, 'r') or die('Cannot open file:  '.$my_file);

$usr_time=$usrtime=fgets($handle);
fclose($handle);

$my_file = 'timer1.txt';
$handle = fopen($my_file, 'r') or die('Cannot open file:  '.$my_file);

$usr_time1=$usrtime1=fgets($handle);
fclose($handle);

$my_file = 'textboy.txt';
$handle = fopen($my_file, 'r') or die('Cannot open file:  '.$my_file);

$text=fgets($handle);
fclose($handle);

?>
<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8" />
	  <link rel="stylesheet" type="text/css" href="style3.css">
	<meta http-equiv="refresh" content="15; url=demo1a.php">
	<iframe id=myIframe style="border:none;float:right;position:absolute;Left:1000;bottom:-350" height="1000" width="300"></iframe>
	<title>LAB 1</title>


	<!-<link rel="stylesheet" href="style3.css">
	<style>
	
	.enjoy-css {
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box;
  margin: -33px;
  position: relative;
  top: 32px;
  padding: 17px 200px;
  border: 2px solid;
  font: normal normal bold 36px/1 "Lucida Console", Monaco, monospace;
  color: white;
  text-align: center;
  text-indent: 190px;
  -o-text-overflow: ellipsis;
  text-overflow: ellipsis;
  letter-spacing: 6px;
  word-spacing: -3px;
  background: url("asd.jpg");
  background-position: 42% -22%;
  -webkit-background-origin: padding-box;
  background-origin: padding-box;
  -webkit-background-clip: border-box;
  background-clip: border-box;
  -webkit-background-size: auto auto;
  background-size: auto auto;
  -webkit-box-shadow: 4px 4px 6px 1px rgba(0,0,0,0.4) ;
  box-shadow: 4px 4px 6px 1px rgba(0,0,0,0.4) ;
  text-shadow: 4px 4px 6px rgba(0,0,0,0.5) ;
  -webkit-transition: all 200ms cubic-bezier(0.42, 0, 0.58, 1) 10ms;
  -moz-transition: all 200ms cubic-bezier(0.42, 0, 0.58, 1) 10ms;
  -o-transition: all 200ms cubic-bezier(0.42, 0, 0.58, 1) 10ms;
  transition: all 200ms cubic-bezier(0.42, 0, 0.58, 1) 10ms;
  -webkit-transform: rotateX(-9.740282517223996deg) rotateY(0.5729577951308232deg)   ;
  transform: rotateX(-9.740282517223996deg) rotateY(0.5729577951308232deg)   ;
}
.marquee {
  height: 30px;
  width: 600px;

  overflow: hidden;
  position: absolute;
  top:+25%;
  left: +65%;
}

.marquee div {
  display: block;
  width: 400%;
  height: 30px;

  position: absolute;
  overflow: hidden;

  animation: marquee 15s linear infinite;
}

.marquee span {
  float: left;
  width: 100%;
  font-size:25px;
  color: blue;
}

@keyframes marquee {
  0% { left: 0; }
  100% { left: -100%; }
}
.marquee1 {
  height: 30px;
  width: 600px;

  overflow: hidden;
  position: absolute;
  top:+20%;
  left: +65%;
}

.marquee1 div {
  display: block;
  width: 400%;
  height: 30px;

  position: absolute;
  overflow: hidden;

  animation: marquee 7s linear infinite;
}

.marquee1 span {
  float: left;
  width: 100%;
  font-size:25px;
  color: green;
}

@keyframes marquee1 {
  0% { left: 0; }
  100% { left: -100%; }
}
</style>
	<?php
	$db = new PDO("mysql:host=localhost;dbname=demo","root","123456");
	foreach($db->query('SELECT * FROM status') as $row)
	?>	
	<script type="text/javascript" src="jquery-1.7.2.min.js"></script>
	<script type="text/javascript">
		
	window.setInterval("reloadIFrame();", 3000);
	function reloadIFrame() {
 	document.getElementById("myIframe").src="piboy.php";
	}


		var x=0;
		var y=0;
		var z=0,a=0;
		var h=0,m=0,s=0;
		
		var string,string1,string2,string3,led1,led2,led3,led4;
		
	

		var h=0,m=0,s=0;
		currentDate = new Date();
	
		var startTime=<?php echo json_encode($usr_time);?>;
		var endTime=<?php echo json_encode($usr_time1);?>;
		startDate = new Date(currentDate.getTime());
		startDate.setHours(startTime.split(":")[0]);
		startDate.setMinutes(startTime.split(":")[1]);
	

		endDate = new Date(currentDate.getTime());
		endDate.setHours(endTime.split(":")[0]);
		endDate.setMinutes(endTime.split(":")[1]);
		
	
		valid = startDate < currentDate && endDate > currentDate;
		if(valid==0)
		{document.getElementById("#button").disabled = true;
		 document.getElementById("#button1").disabled = true;
		 document.getElementById("#button2").disabled = true;
		 document.getElementById("#button3").disabled = true;
                }
		$(document).ready(function(){
				
				string = "<?php echo $row['AC1']; ?>";
				
				if(string == "ON")
				{x=1;
				$('#button').toggleClass('on');
				}				
				else
				x=0;
				string1 = "<?php echo $row['AC2']; ?>";
				
				if(string1 == "ON")
				{y=1;
				$('#button1').toggleClass('on');
				}				
				else
				y=0;
				string2 = "<?php echo $row['AC3']; ?>";
				
				if(string2 == "ON")
				{z=1;
				$('#button2').toggleClass('on');
				}				
				else
				z=0;
				string3 = "<?php echo $row['AC4']; ?>";
				
				if(string3 == "ON")
				{a=1;
				$('#button3').toggleClass('on');
				}				
				else
				a=0;

			<?php
	foreach($db->query('SELECT * FROM statusled') as $row)
	?>
		led1 = "<?php echo $row['AC1']; ?>";
				
				if(led1 == "ON"&& string == "ON")
				{
				$('.led').toggleClass('led-green');
				}				
				else if(led1 == "OFF"&& string == "ON")
				$('.led').toggleClass('led-orange');

				led2 = "<?php echo $row['AC2']; ?>";
				
				if(led2 == "ON" && string1 == "ON")
				{
				$('.leda').toggleClass('leda-green');
				}				
				else if(led2 == "OFF"&& string1 == "ON")
				$('.leda').toggleClass('leda-orange');


				led3 = "<?php echo $row['AC3']; ?>";
				
				if(led3 == "ON" && string2 == "ON")
				{
				$('.ledb').toggleClass('ledb-green');
				}				
				else if(led3 == "OFF"&& string2 == "ON")
				$('.ledb').toggleClass('ledb-orange');

				led4 = "<?php echo $row['AC4']; ?>";
				
				if(led4 == "ON" && string3 == "ON")
				{
				$('.ledc').toggleClass('ledc-green');
				}				
				else if(led4 == "OFF"&& string3 == "ON")
				$('.ledc').toggleClass('ledc-orange');

			$('#button').on('click', function(){
				
				if(x%2==0)
				{
				
				 $(this).toggleClass('on');
				$('.led').toggleClass('led-orange');
				 $.post("demo.php",{
				 status:"on"});
			        $.post("demo2.php",{
				status:"ON"},function(data) {
                     $('#stage').html(data);
                  });
				
				}
				
				else
				{
				$(this).toggleClass('on');
				$('.led').toggleClass('led-orange');
				$.post("demo.php",{
				status:"off"});
				$.post("demo2.php",{
				status:"OFF"},function(data) {
                     $('#stage').html(data);
                  });
				
				}
				x++;
			});
			$('#button1').on('click', function(){
				$(this).toggleClass('on');
				$('.leda').toggleClass('leda-orange');
				
				if(y%2==0)
				{
								
				$.post("demo.php",{
				status:"ona"});
				$.post("demo3.php",{
				status:"ONA"},function(data) {
                     $('#stage').html(data);
                  });			
				
				}
				else
				{
				$.post("demo.php",{
				status:"offa"});
				$.post("demo3.php",{
				status:"OFFA"},function(data) {
                     $('#stage').html(data);
                  });
				
				}
				y++;
			});
			$('#button2').on('click', function(){
				$(this).toggleClass('on');
				$('.ledb').toggleClass('ledb-orange');
				if(z%2==0)
				{
				
				$.post("demo.php",{
				status:"onb"},function(data) {
                     	$('#stage').html(data)});
				$.post("demo4.php",{
				status:"ONB"},function(data) {
                     $('#stage').html(data);
                  });		
				}
			
			
				
				else
				{
				$.post("demo.php",{
				status:"offb"});
				$.post("demo4.php",{
				status:"OFFB"},function(data) {
                     $('#stage').html(data);
                  });
				
				}
				z++;
			});
			$('#button3').on('click', function(){
				$(this).toggleClass('on');
				$('.ledc').toggleClass('ledc-orange');
				if(a%2==0)
				{
				
				$.post("demo.php",{
				status:"onc"});		
				$.post("demo5.php",{
				status:"ONC"},function(data) {
                     $('#stage').html(data);
                  });		
				
				
				}
				else
				{
				$.post("demo.php",{
				status:"offc"});
				$.post("demo5.php",{
				status:"OFFC"},function(data) {
                     $('#stage').html(data);
                  });
			
				}
				a++;
			});
		});
	</script>
</head>
<body>
<div class="enjoy-css">Embedded Power Supervisor- ESG Lab</div>
<br>
<br>
<br>
<br>

<div class="marquee">  
<div>
    <span>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<?php echo "The working time set between     ".$usrtime."   to  ".$usrtime1;?> </span>
  </div>
</div>  

<div class="marquee1">
  
<div>
    <span>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp***<?php echo $text;?>*** </span>

  </div>
</div>  	
<section>
		<p style="position:relative;right:5px; font-size:25px;color:white;">Indicator</p>
		<a1 href="#" id="button" >AC1</a1>
		<div class="led"></div>
		<a2 href="#" id="button1" >AC2</a2>
		<div class="leda"></div>
		<a3 href="#" id="button2" >AC3</a3>
		<div class="ledb"></div>
		<a4 href="#" id="button3" >AC4</a4>
		<div class="ledc"></div>
		<span></span>
	</section>


</body>

 
</html>
  
