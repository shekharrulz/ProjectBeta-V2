<?php
// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}
$displayname=$_SESSION['username'];
date_default_timezone_set("Asia/Kolkata");
$date = date('d/m/Y h:i a', time());
echo "<div class='topnav'><a href='#'>Embedded Power Supervisor</a>";
echo "<a class='active'href='button.php'>Home</a>";
echo "<a href='#'>";
echo "<div class='dropdown '>";
echo $displayname;
echo "<div class='dropdown-content'>";
echo "<a href='logout.php'>Logout</a></div>";
echo "</a></div>";
echo "<a class='right'>";
echo $date;
echo "<a class='active'href='settings.php'>Settings</a>";
echo "</a></div>";

$my_file = 'timer.txt';
$handle = fopen($my_file, 'r') or die('Cannot open file:  '.$my_file);

$usr_time=fgets($handle);
fclose($handle);

$my_file = 'timer1.txt';
$handle = fopen($my_file, 'r') or die('Cannot open file:  '.$my_file);

$usr_time1=fgets($handle);
fclose($handle);
?>
<!DOCTYPE html>
<html lang="en" >

<head>
  <link rel="icon" href="logo.png" type="image" sizes="16x16">
  <meta charset="UTF-8">
  
  <title>Home page !!!!</title>
  <meta http-equiv="refresh" content="60; url=button.php">
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<script type="text/javascript">		

	var h=0,m=0,s=0;
	currentDate = new Date();
	
	var startTime=<?php echo json_encode($usr_time);?>;
	var endTime=<?php echo json_encode($usr_time1);?>;
	startDate = new Date(currentDate.getTime());
	startDate.setHours(startTime.split(":")[0]);
	startDate.setMinutes(startTime.split(":")[1]);
	

	endDate = new Date(currentDate.getTime());
	endDate.setHours(endTime.split(":")[0]);
	endDate.setMinutes(endTime.split(":")[1]);
		
	
	valid = startDate < currentDate && endDate > currentDate;
	
	function redirect1() {
        if(valid==0){
	
	alert("Operation starts between 10:30 AM to 5:30 PM....Button disabled");
	
	}	
	else	
	{location.href = "demo1.php";}
	
}
function redirect2() {
        if(valid==0){
	
	alert("Operation starts between 10:30 AM to 5:30 PM....Button disabled");
	
	}	
	else	
	{location.href = "demo1.php";}
	
}
function redirect3() {
        if(valid==0){
	
	alert("Operation starts between 10:30 AM to 5:30 PM....Button disabled");
	
	}	
	else	
	{location.href = "demo1.php";}
	
}
function redirect4() {
        if(valid==0){
	
	alert("Operation starts between 10:30 AM to 5:30 PM....Button disabled");
	
	}	
	else	
	{location.href = "demo1.php";}
	
}
function redirect5() {
        location.href = "settings.php";}
	

function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('txt').innerHTML =
    h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
</script>


<body>
<div class="heading">Embedded Power Supervisor</div>

<button id="button1" class="enjoy-css" onClick="redirect1()" >LAB 1</button>
<button id="button2" class="but1" onClick="redirect2()">LAB 2</button>

<button id="button3" class="but2" onClick="redirect3()">LAB 3</button>

<button id="button4" class="but3" onClick="redirect4()">LAB 4</button>

<div class="text-bot">Developed by PROJECT BETA</div>
</body>
</head>
</html>

