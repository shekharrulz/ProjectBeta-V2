<?php
//chart for temp and conductivity
$connect = mysqli_connect("localhost", "new", "root", "myDBS");
$query = "SELECT tmp,date_time FROM temp1";
$result = mysqli_query($connect, $query);
$chart_data = '';
while($row = mysqli_fetch_array($result))
{
       echo "tmp: " . $row["tmp"]. " -date_time : " . $row["date_time"]. "<br>";
}
//$chart_data = substr($chart_data, 0, -2);
?>
