<?php
$link = mysqli_connect("localhost", "root", "123456", "demo");
if($link === false){

    echo "ERROR: Could not connect. ";

}
if($_REQUEST["status"])
{
$status=$_REQUEST['status'];
if($status == 'on')
{
$sql = "UPDATE status SET AC1 = 'ON' LIMIT 1";

if(mysqli_query($link, $sql))
    echo "Records inserted successfully.";
else{

    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);

}
//echo "STATUS of LED1 is ".$status;
mysqli_close($link);
}
else if($status == 'off')
{
$sql = "UPDATE status SET AC1 = 'OFF' LIMIT 1";

if(mysqli_query($link, $sql))
    echo "Records inserted successfully.";
else{

    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);

}
//echo "STATUS of LED1 is ".$status;
mysqli_close($link);
}
if($status == 'ona')
{
$sql = "UPDATE status SET AC2 = 'ON' LIMIT 1";

if(mysqli_query($link, $sql))
    echo "Records inserted successfully.";
else{

    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);

}
//echo "STATUS of LED1 is ".$status;
mysqli_close($link);
}
if($status == 'offa')
{
$sql = "UPDATE status SET AC2 = 'OFF' LIMIT 1";

if(mysqli_query($link, $sql))
    echo "Records inserted successfully.";
else{

    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);

}
//echo "STATUS of LED1 is ".$status;
mysqli_close($link);
}
if($status == 'onb')
{
$sql = "UPDATE status SET AC3 = 'ON' LIMIT 1";

if(mysqli_query($link, $sql))
    echo "Records inserted successfully.";
else{

    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);

}
//echo "STATUS of LED1 is ".$status;
mysqli_close($link);
}
if($status == 'offb')
{
$sql = "UPDATE status SET AC3 = 'OFF' LIMIT 1";

if(mysqli_query($link, $sql))
    echo "Records inserted successfully.";
else{

    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);

}
//echo "STATUS of LED1 is ".$status;
mysqli_close($link);
}
if($status == 'onc')
{
$sql = "UPDATE status SET AC4 = 'ON' LIMIT 1";

if(mysqli_query($link, $sql))
    echo "Records inserted successfully.";
else{

    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);

}
//echo "STATUS of LED1 is ".$status;
mysqli_close($link);
}
if($status == 'offc')
{
$sql = "UPDATE status SET AC4 = 'OFF' LIMIT 1";

if(mysqli_query($link, $sql))
    echo "Records inserted successfully.";
else{

    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);

}
//echo "STATUS of LED1 is ".$status;
mysqli_close($link);
}
}
?>
