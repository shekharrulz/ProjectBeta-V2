from websocket import create_connection
import sys
import ssl

def read_file():
    with open("on_off.txt", "r") as f:
        SMRF1 = f.readlines()
    return SMRF1
def read_file1():
    with open("on_off1.txt", "r") as f1:
        SMRF1 = f1.readlines()
    return SMRF1
def read_file2():
    with open("on_off2.txt", "r") as f2:
        SMRF1 = f2.readlines()
    return SMRF1
def read_file3():
    with open("on_off3.txt", "r") as f3:
        SMRF1 = f3.readlines()
    return SMRF1



initial = read_file()
initial1 = read_file1()
initial2 = read_file2()
initial3 = read_file3()

for line in initial:
	ws = create_connection("ws://192.168.16.76")
	print ("Sending 'Hello, World'...")
	str=line
	ws.send(str)
	ws.close()
for line in initial1:
	ws = create_connection("ws://192.168.16.76")
	print ("Sending 'Hello, World'...")
	str=line
	ws.send(str)
	ws.close()
for line in initial2:
	ws = create_connection("ws://192.168.16.76")
	print ("Sending 'Hello, World'...")
	str=line
	ws.send(str)
	ws.close()
for line in initial3:
	ws = create_connection("ws://192.168.16.76")
	print ("Sending 'Hello, World'...")
	str=line
	ws.send(str)
	ws.close()

while True:
	current = read_file()
	current1 = read_file1()
	current2 = read_file2()
	current3 = read_file3()
	if initial != current:
		for line in current:
			if line not in initial:
				print(line)
			
				ws = create_connection("ws://192.168.16.76")
				print ("Sending 'Hello, World'...")
				str=line
				ws.send(str)
				ws.close()
		initial = current
	if initial1 != current1:
		for line1 in current1:
			if line1 not in initial1:
				print(line1)
			
				ws = create_connection("ws://192.168.16.76")
				print ("Sending 'Hello, World'...")
				str=line1
				ws.send(str)
				ws.close()
		initial1 = current1
	if initial2 != current2:
		for line2 in current2:
			if line2 not in initial2:
				print(line2)
			
				ws = create_connection("ws://192.168.16.76")
				print ("Sending 'Hello, World'...")
				str=line2
				ws.send(str)
				ws.close()
		initial2 = current2
	if initial3 != current3:
		for line3 in current3:
			if line3 not in initial3:
				print(line3)
			
				ws = create_connection("ws://192.168.16.76")
				print ("Sending 'Hello, World'...")
				str=line3
				ws.send(str)
				ws.close()
		initial3 = current3
