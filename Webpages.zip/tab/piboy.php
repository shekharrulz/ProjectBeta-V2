<?php

$lines_array = file("/var/www/html/tab/foo.txt");

foreach($lines_array as $line) {
    if(strpos($line, "Current1") !== false) {
        list(, $new_str1) = explode(":", $line);
        // If you don't want the space before the word bong, uncomment the following line.
        //$new_str = trim($new_str);
    }
    if(strpos($line, "Current2") !== false) {
        list(, $new_str2) = explode(":", $line);
        // If you don't want the space before the word bong, uncomment the following line.
        //$new_str = trim($new_str);
    }
    if(strpos($line, "Current3") !== false) {
        list(, $new_str3) = explode(":", $line);
        // If you don't want the space before the word bong, uncomment the following line.
        //$new_str = trim($new_str);
    }
    if(strpos($line, "Current4") !== false) {
        list(, $new_str4) = explode(":", $line);
        // If you don't want the space before the word bong, uncomment the following line.
        //$new_str = trim($new_str);
    }
    if(strpos($line, "Current5") !== false) {
        list(, $new_str5) = explode(":", $line);
        // If you don't want the space before the word bong, uncomment the following line.
        //$new_str = trim($new_str);
    }
   
}

?>

<!doctype html>

<html>
  <head>
    <title>Auto-adjust</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <style>
      body {
        text-align: center;
      }

 

      p {
        display: block;
        width: 450px;
        margin: 2em auto;
        text-align: left;
      }
    </style>


  </head>
  <body>
    <div id="g1"></div>
    <div id="g2"></div>
    <div id="g3"></div>
    <div id="g4"></div>
     <div id="g5"></div>

    <script src="raphael-2.1.4.min.js"></script>
    <script src="justgage.js"></script>
    <script>
      var g1, g2, g3, g4;

      window.onload = function(){
        var g1 = new JustGage({
          id: "g1",
          value: <?php echo (int)$new_str1?>,
          min: 0,
          max: 15,
          title: "Current AC1",
          label: "A",
	titleFontColor: "#fff",
	labelFontColor: "#fff",
	startAnimationTime: 1,
        startAnimationType: "linear",
        refreshAnimationTime: 1,
        refreshAnimationType: "linear"

        });

        var g2 = new JustGage({
          id: "g2",
          value: <?php echo (int)$new_str2?>,
          min: 0,
          max: 15,
          title: "Current AC2",
          label: "A",
	titleFontColor: "#fff",
	labelFontColor: "#fff",
	startAnimationTime: 1,
        startAnimationType: "linear",
        refreshAnimationTime: 1,
        refreshAnimationType: "linear"
        });

        var g3 = new JustGage({
          id: "g3",
          value: <?php echo (int)$new_str3?>,
          min: 0,
          max: 15,

          title: "Current AC3",
          label: "A",
	titleFontColor: "#fff",
	labelFontColor: "#fff",
	startAnimationTime: 1,
        startAnimationType: "linear",
        refreshAnimationTime: 1,
        refreshAnimationType: "linear"
        });

        var g4 = new JustGage({
          id: "g4",
          value: <?php echo (int)$new_str4?>,
          min: 0,
          max: 15,
          title: "Current AC4",
          label: "A",
	titleFontColor: "#fff",
	labelFontColor: "#fff",
	startAnimationTime: 1,
        startAnimationType: "linear",
        refreshAnimationTime: 1,
        refreshAnimationType: "linear"
        });
	var g5 = new JustGage({
          id: "g5",
          value: <?php echo (int)$new_str5?>,
          min: 200,
          max: 240,
          title: "Total Voltage",
          label: "V",
	titleFontColor: "#fff",
	labelFontColor: "#fff",
	startAnimationTime: 1,
        startAnimationType: "linear",
        refreshAnimationTime: 1,
        refreshAnimationType: "linear"
        });

     
      };
    </script>
  </body>
</html>



